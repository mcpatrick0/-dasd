<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <link rel="stylesheet" type="text/css" href="Bootstrap-4-4.1.1/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"/>

        <script type="text/javascript" src="jQuery-3.3.1/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="Bootstrap-4-4.1.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="DataTables-1.10.18/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="DataTables-1.10.18/js/dataTables.bootstrap4.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#results').load();
            });
        </script>
        <script>
            $(document).ready(function () {
                $('#myTable').DataTable({
                    order: [[2, 'asc']],
                    rowGroup: {
                        endRender: function (rows, group) {
                            var avg = rows
                                    .data()
                                    .pluck(5)
                                    .reduce(function (a, b) {
                                        return a + b.replace(/[^\d]/g, '') * 1;
                                    }, 0) / rows.count();

                            return 'Average salary in ' + group + ': ' +
                                    $.fn.dataTable.render.number(',', '.', 0, '$').display(avg);
                        },
                        dataSrc: 2
                    }
                });

                $('#myTable').on('click', '#getId', function () {
                    var currentRow = $(this).closest('tr');
                    var col1 = currentRow.find("td:eq(0)").text();
                    alert(col1);
                    $.post("") {
                        
                    }
                });
            });
        </script>
        <script>

        </script>

        <style>
            tr .group, tr .group:hover {
                background-color: #ddd !important;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <p>Ezman</p>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-2">
                            <button class='btn btn-link'>Show all</button>
                        </div>
                        <div class="col-md-2">
                            <button class='btn btn-link'>Banned tickets</button>
                        </div>
                        <div class="col-md-2">
                            <button class='btn btn-link'>Unbanned tickets</button>
                        </div>
                        <div class="col-md-6">
                        </div>
                    </div>
                    <br><br>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <table id='myTable' class='display' style="width:100%;">
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>IP address</td>
                        <td>Datetime</td>
                        <td>Status</td>
                        <td>Detail</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody id="results">
                    <?php
                    // put your code here
                    $db_host = "localhost:3306";
                    $db_user = "root";
                    $db_pass = "Chinh123";
                    $db_name = "doanDB";

                    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = "SELECT * FROM ticket_storage ORDER BY ticketId DESC";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>" . $row['ticketId'] . "</td>";
                            echo "<td>" . $row['ticketIp'] . "</td>";
                            echo "<td>" . $row['ticketTime'] . "</td>";
                            if ($row['ticketStatus'] % 2 == 0) {
                                echo "<td>Banned</td>";
                            } else {
                                echo "<td>Unbanned</td>";
                            }
                            echo "<td>" . $row['ticketDetail'] . "</td>";
                            if ($row['ticketStatus'] % 2 == 0) {
                                echo "<td><button id='getId' type='button' class='btn btn-warning' >Unban</button></td></tr>";
                            } else {
                                echo "<td><button id='getId' type='button' class='btn disabled' >Unban</button></td></tr>";
                            }
                        }
                    }
                    ?>
                <tbody>
            </table>
        </div>
        <div class="footer">
            <p>Footer</p>
        </div>
    </body>
</html>
